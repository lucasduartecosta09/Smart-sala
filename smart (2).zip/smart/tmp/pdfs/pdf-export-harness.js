(async () => {
  const resultado = document.getElementById('resultado');
  try {
    const resposta = await fetch('../../index.html');
    const fonteHtml = await resposta.text();
    const documento = new DOMParser().parseFromString(fonteHtml, 'text/html');
    documento.querySelectorAll('script').forEach((script) => script.remove());
    document.body.replaceChildren(...documento.body.children);
    document.body.appendChild(resultado);

    let inicio;
    let estado;
    let renderizar;
    window.senaiAuth = {
      canOperatePanel: () => true,
      start(iniciar, estadoRecebido, desenhar) {
        inicio = iniciar;
        estado = estadoRecebido;
        renderizar = desenhar;
      },
      saveReading() {},
      saveEvent() {}
    };
    let pdfGerado = null;
    const criarObjectUrl = URL.createObjectURL.bind(URL);
    URL.createObjectURL = (blob) => {
      pdfGerado = blob;
      return criarObjectUrl(blob);
    };
    URL.revokeObjectURL = () => {};
    HTMLAnchorElement.prototype.click = async function () {
      const bytes = new Uint8Array(await pdfGerado.arrayBuffer());
      const texto = new TextDecoder().decode(bytes);
      const verificacoes = {
        tipo: pdfGerado.type,
        nome: this.download,
        assinatura: texto.startsWith('%PDF-1.4'),
        final: texto.endsWith('%%EOF'),
        paginas: texto.includes('/Type /Pages /Count 2'),
        total: texto.includes('(Total: 25 leituras)'),
        linhas: (texto.match(/\(29\/10\/2026\)/g) || []).length,
        cabecalhos: ['Temperatura \\(C\\)', 'Umidade \\(%\\)', 'Luminosidade \\(%\\)', 'Pessoas']
          .every((titulo) => texto.includes(`(${titulo})`))
      };
      resultado.textContent = JSON.stringify(verificacoes);
      let binario = '';
      for (let inicio = 0; inicio < bytes.length; inicio += 8192) {
        binario += String.fromCharCode(...bytes.slice(inicio, inicio + 8192));
      }
      resultado.dataset.pdfBase64 = btoa(binario);
      document.body.dataset.testeConcluido = Object.values(verificacoes).every(Boolean) && verificacoes.linhas === 25
        ? 'ok'
        : 'falhou';
      const visualizacao = document.createElement('embed');
      visualizacao.src = this.href;
      visualizacao.type = 'application/pdf';
      visualizacao.style.cssText = 'display:block;width:100%;height:820px;border:0';
      setTimeout(() => document.body.replaceChildren(resultado, visualizacao), 0);
    };

    await new Promise((resolve, reject) => {
      const script = document.createElement('script');
      script.src = '../../app.js';
      script.onload = resolve;
      script.onerror = reject;
      document.head.appendChild(script);
    });
    document.dispatchEvent(new Event('DOMContentLoaded'));
    if (!inicio || !estado || !renderizar) throw new Error('aplicativo não iniciou');
    inicio();
    estado.historico = Array.from({ length: 25 }, (_, indice) => ({
      hora: new Date(Date.UTC(2026, 9, 29, 12, 0, indice * 5)),
      temperatura: 20 + indice / 10,
      umidade: 40 + indice,
      luminosidade: 50 + indice,
      pessoas: indice
    }));
    estado.sensores = { ...estado.historico.at(-1) };
    renderizar();
    document.getElementById('btn-baixar').click();
  } catch (erro) {
    resultado.textContent = String(erro?.stack || erro);
    document.body.dataset.testeConcluido = 'falhou';
  }
})();
