import { createServer } from 'node:http';
import { readFileSync, mkdirSync, writeFileSync } from 'node:fs';
import { resolve, join } from 'node:path';
import { spawn } from 'node:child_process';
import assert from 'node:assert/strict';

const root = process.cwd();
const output = resolve(root, '.system_generated');
mkdirSync(output, { recursive: true });
const original = readFileSync(join(root, 'index.html'), 'utf8');
// Fixture de teste: o produto mantém seus scripts e sua autenticação originais.
const fixture = original
  .replace(/<script src="https:[^>]*><\/script>/, '')
  .replace('<script src="senai-auth.js" defer></script>', '<script src="/__auth-stub__.js" defer></script>');
const authStub = `window.senaiAuth = {
  canOperatePanel: () => true,
  start(init, estado, render) {
    init();
    document.getElementById('senai-login').hidden = true;
    window.__dashboardTest = { estado, render };
  }
};`;
const files = new Map([
  ['/app.js', ['app.js', 'text/javascript']],
  ['/theme-init.js', ['theme-init.js', 'text/javascript']],
  ['/visual.css', ['visual.css', 'text/css']],
  ['/senai-auth.css', ['senai-auth.css', 'text/css']],
  ['/assets/dashboard-carousel.js', ['assets/dashboard-carousel.js', 'text/javascript']],
  ['/assets/dashboard-carousel.css', ['assets/dashboard-carousel.css', 'text/css']]
]);
const requests = [];
const server = createServer((req, res) => {
  requests.push(req.url);
  if (req.url === '/favicon.ico') { res.writeHead(204); res.end(); return; }
  if (req.url === '/') { res.setHeader('Content-Type', 'text/html; charset=utf-8'); res.end(fixture); return; }
  if (req.url === '/__auth-stub__.js') { res.setHeader('Content-Type', 'text/javascript'); res.end(authStub); return; }
  const file = files.get(req.url);
  if (!file) { res.writeHead(404); res.end(); return; }
  res.setHeader('Content-Type', `${file[1]}; charset=utf-8`);
  res.end(readFileSync(join(root, file[0])));
});
await new Promise((r) => server.listen(0, '127.0.0.1', r));
const base = `http://127.0.0.1:${server.address().port}`;
const browser = spawn('C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe', [
  '--headless=new', '--disable-gpu', '--no-first-run', '--no-default-browser-check',
  '--remote-debugging-port=0', `--user-data-dir=${join(output, 'chrome-profile')}`, 'about:blank'
], { windowsHide: true, stdio: ['ignore', 'ignore', 'pipe'] });
let ws;
try {
  const endpoint = await new Promise((r, reject) => {
    let stderr = '';
    const timer = setTimeout(() => reject(new Error(`Chrome não iniciou: ${stderr.slice(-1000)}`)), 15000);
    browser.on('error', reject);
    browser.stderr.on('data', (data) => {
      stderr += data;
      const match = stderr.match(/DevTools listening on (ws:\/\/[^\s]+)/);
      if (match) { clearTimeout(timer); r(match[1]); }
    });
  });
  const debug = new URL(endpoint);
  const target = await (await fetch(`http://${debug.host}/json/new?about:blank`, { method: 'PUT' })).json();
  ws = new WebSocket(target.webSocketDebuggerUrl);
  await new Promise((r, reject) => { ws.addEventListener('open', r, { once: true }); ws.addEventListener('error', reject, { once: true }); });
  const pending = new Map(), errors = [];
  let nextId = 0;
  ws.addEventListener('message', ({ data }) => {
    const message = JSON.parse(data);
    if (message.id) {
      const p = pending.get(message.id);
      if (p) { pending.delete(message.id); message.error ? p.reject(new Error(JSON.stringify(message.error))) : p.resolve(message.result); }
    }
    if (message.method === 'Runtime.exceptionThrown') errors.push(message.params.exceptionDetails);
    if (message.method === 'Log.entryAdded' && message.params.entry.level === 'error') errors.push(message.params.entry);
  });
  function send(method, params = {}) {
    return new Promise((resolve, reject) => {
      const id = ++nextId;
      pending.set(id, { resolve, reject });
      ws.send(JSON.stringify({ id, method, params }));
    });
  }
  async function evaluate(expression) {
    const result = await send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true });
    if (result.exceptionDetails) throw new Error(JSON.stringify(result.exceptionDetails));
    return result.result.value;
  }
  await send('Runtime.enable');
  await send('Log.enable');
  await send('Page.enable');
  await send('Emulation.setDeviceMetricsOverride', { width: 1440, height: 1000, deviceScaleFactor: 1, mobile: false });
  await send('Page.navigate', { url: base });
  const start = Date.now();
  while (!(await evaluate('Boolean(window.__dashboardTest)'))) {
    if (Date.now() - start > 10000) throw new Error('Dashboard não inicializou');
    await new Promise((r) => setTimeout(r, 100));
  }
  await evaluate(`(() => {
    const { estado, render } = window.__dashboardTest;
    const inicio = Date.UTC(2026, 9, 29, 15);
    estado.historico = Array.from({ length: 16 }, (_, i) => ({
      hora: new Date(inicio + i * 5000), temperatura: 23 + Math.sin(i / 2),
      umidade: 52 + Math.round(Math.cos(i / 3) * 8), pessoas: i % 8,
      luminosidade: 60 + Math.round(Math.sin(i / 3) * 12)
    }));
    estado.sensores = { ...estado.historico.at(-1) }; render();
  })()`);
  const carouselStart = Date.now();
  while (!(await evaluate(`Boolean(document.querySelector('.dashboard-carousel .circular-carousel[data-ready]'))`))) {
    if (Date.now() - carouselStart > 10000) throw new Error('Carrossel React não inicializou');
    await new Promise(r => setTimeout(r, 100));
  }
  assert.equal(await evaluate(`document.getElementById('carousel-fallback').hidden`), true);
  assert.equal(await evaluate(`document.querySelectorAll('.circular-carousel [data-cc-index]').length`), 4);
  const reports = [];
  for (const view of [
    { width: 1440, height: 1000, tema: 'escuro' },
    { width: 1440, height: 1000, tema: 'claro' },
    { width: 1920, height: 1080, tema: 'escuro' },
    { width: 768, height: 1024, tema: 'escuro' },
    { width: 375, height: 812, tema: 'escuro' }
  ]) {
    await send('Emulation.setDeviceMetricsOverride', { ...view, deviceScaleFactor: 1, mobile: view.width < 500 });
    await evaluate(`document.documentElement.dataset.tema = '${view.tema}'; window.dispatchEvent(new Event('resize')); new Promise(r => requestAnimationFrame(() => requestAnimationFrame(r)))`);
    await evaluate(`document.dispatchEvent(new Event('dashboard:close')); new Promise(r => requestAnimationFrame(() => requestAnimationFrame(r)))`);
    await new Promise(r => setTimeout(r, 500));
    const initial = await evaluate(`(() => {
      const roleta = document.querySelector('.carousel-shell');
      const r = roleta.getBoundingClientRect();
      return { hidden: document.getElementById('dashboard-detalhes').hidden, height: r.height, ratio: r.width / document.querySelector('.conteudo').clientWidth, pageWidth: document.documentElement.scrollWidth, viewport: innerWidth };
    })()`);
    assert.equal(initial.hidden, true, 'os gráficos começam recolhidos e só a roleta é mostrada');
    assert.ok(initial.height >= view.height * .6, 'a roleta ocupa a altura disponível');
    assert.ok(initial.ratio > 0.85, `a roleta deve ocupar a largura disponível: ${initial.ratio}`);
    assert.ok(initial.pageWidth <= initial.viewport + 1, 'sem overflow na roleta');
    const overviewScreen = await send('Page.captureScreenshot', { format: 'png', captureBeyondViewport: true });
    writeFileSync(join(output, `roleta-${view.width}-${view.tema}.png`), Buffer.from(overviewScreen.data, 'base64'));
    const opened = await evaluate(`(() => {
      document.dispatchEvent(new CustomEvent('dashboard:open', { detail: { chave: 'temperatura' } }));
      return { visible: !document.getElementById('dashboard-detalhes').hidden, autoDetails: !document.getElementById('graficos-complementares').hidden, zoom: document.getElementById('dashboard-detalhes').getAnimations().length };
    })()`);
    assert.ok(opened.visible && opened.autoDetails && opened.zoom > 0, 'seleção abre com zoom e detalhes imediatos');
    await new Promise(r => setTimeout(r, 420));
    await evaluate(`document.getElementById('btn-restaurar-graficos').click()`);
    await evaluate(`(() => {
      const canvas = document.getElementById('grafico-temperatura');
      const r = canvas.getBoundingClientRect();
      canvas.dispatchEvent(new PointerEvent('pointermove', { clientX: r.left + r.width / 2, clientY: r.top + 80, pointerType: 'mouse' }));
    })(); new Promise(r => requestAnimationFrame(() => requestAnimationFrame(r)))`);
    const report = await evaluate(`(() => {
      const rect = el => { const r = el.getBoundingClientRect(); return { width: r.width, height: r.height, left: r.left, right: r.right, top: r.top, bottom: r.bottom }; };
      return {
        viewport: innerWidth, pageWidth: document.documentElement.scrollWidth,
        columns: getComputedStyle(document.querySelector('.historicos-grade')).gridTemplateColumns,
        charts: [...document.querySelectorAll('canvas.grafico')].map(el => ({ id: el.id, ...rect(el), label: el.getAttribute('aria-label') })),
        clipped: [...document.querySelectorAll('.metrica, .kpi-mini')].filter(el => el.scrollWidth > el.clientWidth + 1).map(el => ({ text: el.textContent.trim(), width: el.clientWidth, scroll: el.scrollWidth })),
        details: !document.getElementById('graficos-complementares').hidden
      };
    })()`);
    assert.ok(report.pageWidth <= report.viewport + 1, `overflow horizontal: ${JSON.stringify(report)}`);
    assert.equal(report.charts.length, 4);
    assert.equal(report.details, true);
    assert.ok(report.charts.every(c => c.width > 0 && c.height > 0 && c.left >= 0 && c.right <= report.viewport + 1));
    assert.ok(report.charts.slice(1).every(c => c.height >= 280 && c.width >= 280 && c.top > report.charts[0].bottom), 'os detalhes ficam abaixo e têm tamanho legível');
    assert.deepEqual(report.clipped, [], `conteúdo cortado: ${JSON.stringify(report.clipped)}`);
    const screenshot = await send('Page.captureScreenshot', { format: 'png', captureBeyondViewport: true });
    const filename = `dashboard-${view.width}-${view.tema}.png`;
    writeFileSync(join(output, filename), Buffer.from(screenshot.data, 'base64'));
    reports.push({ ...view, ...report, screenshot: filename });
  }
  await send('Emulation.setDeviceMetricsOverride', { width: 1440, height: 1000, deviceScaleFactor: 1, mobile: false });
  await evaluate(`document.documentElement.dataset.tema = 'escuro'; window.dispatchEvent(new Event('resize')); new Promise(r => requestAnimationFrame(() => requestAnimationFrame(r)))`);
  await evaluate(`document.getElementById('btn-restaurar-graficos').click()`);
  const focusPoint = await evaluate(`(() => {
    const canvas = document.getElementById('grafico-temperatura');
    canvas.scrollIntoView({ block: 'center' });
    const r = canvas.getBoundingClientRect();
    return { x: r.left + 54 + (r.width - 70) * 5 / 15, y: r.top + 80 };
  })()`);
  await send('Input.dispatchMouseEvent', { type: 'mouseMoved', ...focusPoint });
  const selected = () => evaluate(`({
    visible: [...document.querySelectorAll('.grafico-tooltip')].filter(e => !e.hidden).length,
    cursors: [...document.querySelectorAll('.grafico-cursor')].filter(e => !e.hidden).length,
    markers: [...document.querySelectorAll('.grafico-marcador')].filter(e => !e.hidden).length,
    times: [...document.querySelectorAll('.grafico-tooltip span')].map(e => e.textContent),
    pinned: document.getElementById('historico-selecao').dataset.fixado,
    summary: document.getElementById('historico-selecao').textContent
  })`);
  const hover = await selected();
  assert.equal(hover.visible, 4);
  assert.equal(hover.cursors, 4);
  assert.equal(hover.markers, 4);
  assert.equal(new Set(hover.times).size, 1);
  const firstContext = await evaluate(`document.getElementById('complementares-contexto').textContent`);
  assert.ok(firstContext.includes('11 leituras'));
  await send('Input.dispatchMouseEvent', { type: 'mouseMoved', x: focusPoint.x + 250, y: focusPoint.y });
  assert.notEqual(await evaluate(`document.getElementById('complementares-contexto').textContent`), firstContext, 'mover no principal atualiza a janela');
  await send('Input.dispatchMouseEvent', { type: 'mouseMoved', ...focusPoint });
  await send('Input.dispatchMouseEvent', { type: 'mousePressed', ...focusPoint, button: 'left', clickCount: 1 });
  await send('Input.dispatchMouseEvent', { type: 'mouseReleased', ...focusPoint, button: 'left', clickCount: 1 });
  await send('Input.dispatchMouseEvent', { type: 'mouseMoved', x: 10, y: 10 });
  assert.equal((await selected()).pinned, 'true');
  assert.equal((await selected()).visible, 4);
  const interactiveScreenshot = await send('Page.captureScreenshot', { format: 'png', captureBeyondViewport: true });
  writeFileSync(join(output, 'dashboard-interativo.png'), Buffer.from(interactiveScreenshot.data, 'base64'));

  async function key(key, code = key) {
    await send('Input.dispatchKeyEvent', { type: 'keyDown', key, code });
    await send('Input.dispatchKeyEvent', { type: 'keyUp', key, code });
  }
  await evaluate(`document.getElementById('grafico-temperatura').focus()`);
  await key('End');
  assert.ok((await selected()).summary.includes('12:01:15'));
  await key('Escape');
  assert.equal((await selected()).visible, 0);
  assert.equal(await evaluate(`document.getElementById('graficos-complementares').hidden`), true);

  const filtered = await evaluate(`(() => {
    const filtro = document.getElementById('historico-filtro');
    filtro.value = '60'; filtro.dispatchEvent(new Event('change'));
    return { label: document.getElementById('grafico-temperatura').getAttribute('aria-label'), count: window.__dashboardTest.estado.historico.length };
  })()`);
  assert.ok(filtered.label.includes('13 leituras'));
  assert.equal(filtered.count, 16);
  await evaluate(`document.querySelector('#dashboard-opcoes summary').click(); document.getElementById('historico-inicio').focus()`);
  await key('Home');
  await key('ArrowRight');
  const slider = await evaluate(`({
    filter: document.getElementById('historico-filtro').value,
    start: document.getElementById('historico-inicio').value,
    label: document.getElementById('grafico-temperatura').getAttribute('aria-label')
  })`);
  assert.equal(slider.filter, 'personalizado');
  assert.equal(slider.start, '1');
  assert.ok(slider.label.includes('15 leituras'));
  await evaluate(`document.getElementById('btn-restaurar-graficos').click()`);

  await send('Emulation.setDeviceMetricsOverride', { width: 375, height: 812, deviceScaleFactor: 1, mobile: true });
  await send('Emulation.setTouchEmulationEnabled', { enabled: true });
  await evaluate(`window.dispatchEvent(new Event('resize')); new Promise(r => requestAnimationFrame(() => requestAnimationFrame(r)))`);
  const touchPoint = await evaluate(`(() => {
    const canvas = document.getElementById('grafico-temperatura');
    canvas.scrollIntoView({ block: 'center' });
    const r = canvas.getBoundingClientRect();
    return { x: r.left + r.width / 2, y: r.top + r.height / 2 };
  })()`);
  await send('Input.dispatchTouchEvent', { type: 'touchStart', touchPoints: [{ ...touchPoint, id: 1 }] });
  await send('Input.dispatchTouchEvent', { type: 'touchEnd', touchPoints: [] });
  assert.equal((await selected()).pinned, 'true');
  assert.equal((await selected()).visible, 4);
  assert.equal(await evaluate(`document.getElementById('graficos-complementares').hidden`), false);
  await evaluate(`document.getElementById('btn-ocultar-detalhes').click()`);
  assert.equal(await evaluate(`document.getElementById('graficos-complementares').hidden`), true);
  assert.equal(await evaluate(`document.activeElement.id`), 'grafico-temperatura');

  // A ilha React deve realmente controlar os canvases existentes, incluindo o novo hover.
  await send('Emulation.setDeviceMetricsOverride', { width: 1440, height: 1000, deviceScaleFactor: 1, mobile: false });
  await send('Emulation.setTouchEmulationEnabled', { enabled: false });
  await evaluate(`document.getElementById('btn-voltar-roleta').click(); new Promise(r => requestAnimationFrame(() => requestAnimationFrame(r)))`);
  await evaluate(`document.querySelector('.circular-carousel').scrollIntoView({ block: 'center' }); document.querySelector('.circular-carousel').focus()`);
  await key('ArrowRight');
  const navigationStart = Date.now();
  while (!(await evaluate(`document.querySelector('#grafico-principal-slot canvas').id === 'grafico-umidade'`))) {
    if (Date.now() - navigationStart > 3000) throw new Error('Teclado do carrossel não selecionou umidade');
    await new Promise(r => setTimeout(r, 50));
  }
  assert.equal(await evaluate(`document.getElementById('dashboard-detalhes').hidden`), true, 'navegar não abre o dashboard');
  for (const chave of ['pessoas', 'luminosidade', 'temperatura']) {
    await evaluate(`document.querySelector('.dashboard-carousel [data-dashboard-metric="${chave}"]').click()`);
    // Aguarda a animação de encaixe, que também publica as posições intermediárias.
    await new Promise(r => setTimeout(r, 1000));
    assert.equal(await evaluate(`document.querySelector('#grafico-principal-slot canvas').id`), `grafico-${chave}`);
    assert.equal(await evaluate(`document.querySelector('.dashboard-carousel').dataset.principal`), chave);
    assert.equal(await evaluate(`document.getElementById('dashboard-detalhes').hidden`), true);
    await evaluate(`document.querySelector('.carousel-abrir').click()`);
    assert.equal(await evaluate(`document.getElementById('dashboard-detalhes').hidden`), false);
    assert.equal(await evaluate(`document.querySelector('.carousel-shell').hidden`), true);
    assert.equal((await selected()).visible, 4, 'a abertura já gera os detalhes da última leitura');
    await new Promise(r => setTimeout(r, 420));
    await evaluate(`(() => {
      const canvas = document.getElementById('grafico-${chave}');
      const r = canvas.getBoundingClientRect();
      canvas.dispatchEvent(new PointerEvent('pointermove', { clientX: r.left + r.width / 2, clientY: r.top + 80, pointerType: 'mouse' }));
    })()`);
    assert.equal((await selected()).visible, 4, 'qualquer sensor escolhido vira o principal interativo');
    assert.equal(await evaluate(`document.querySelectorAll('canvas.grafico').length`), 4, 'navegar não duplica gráficos');
    await evaluate(`document.getElementById('btn-voltar-roleta').click(); new Promise(r => requestAnimationFrame(() => requestAnimationFrame(r)))`);
  }

  await evaluate(`document.querySelector('.circular-carousel').scrollIntoView({ block: 'center' })`);
  const carouselScreen = await send('Page.captureScreenshot', { format: 'png', captureBeyondViewport: true });
  writeFileSync(join(output, 'dashboard-carrossel.png'), Buffer.from(carouselScreen.data, 'base64'));

  const cardPoint = await evaluate(`(() => {
    const r = document.querySelector('.circular-carousel [data-cc-index="0"] .circular-carousel__photo').getBoundingClientRect();
    return { x: r.left + r.width / 2, y: r.top + r.height / 2 };
  })()`);
  await send('Input.dispatchMouseEvent', { type: 'mouseMoved', ...cardPoint });
  await send('Input.dispatchMouseEvent', { type: 'mousePressed', ...cardPoint, button: 'left', clickCount: 1 });
  await send('Input.dispatchMouseEvent', { type: 'mouseReleased', ...cardPoint, button: 'left', clickCount: 1 });
  assert.equal(await evaluate(`document.getElementById('dashboard-detalhes').hidden`), false, 'clique nativo no cartão abre o dashboard');
  assert.equal((await selected()).visible, 4);

  assert.deepEqual(errors, [], 'erros no navegador');
  const interactions = { fullscreenRoulette: true, zoomOnSelection: true, immediateDetails: true, nativeCardClick: true, backToRoulette: true, circularCarousel: true, carouselKeyboard: true, carouselChangesMainChart: true, contextualHover: true, contextWindowChanges: true, pinnedClick: true, keyboard: true, periodFilter: true, nativeSlider: true, nativeTouch: true, hideDetails: true };
  writeFileSync(join(output, 'browser-report.json'), JSON.stringify({ reports, interactions, errors, requests }, null, 2));
  console.log(JSON.stringify({ reports: reports.map(({ width, tema, columns, pageWidth, charts }) => ({ width, tema, columns, pageWidth, charts: charts.length })), interactions, errors, requests }));
  await send('Browser.close');
} finally {
  ws?.close();
  browser.kill();
  server.close();
}
